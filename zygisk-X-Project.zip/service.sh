#!/system/bin/sh

# Wait for boot to complete
until [ "$(getprop sys.boot_completed)" = "1" ]; do
    sleep 1
done

# Wait for network connectivity
until ping -c 1 your-server.com; do
    sleep 5
done

MODDIR="/data/adb/modules/template_p"
UPDATE_LOCK="/data/adb/xproject_update.lock"

# Only run if not already running
if [ -f "$UPDATE_LOCK" ]; then
    exit 0
fi

touch "$UPDATE_LOCK"

# Check for updates daily
LAST_CHECK=0
if [ -f "/data/adb/xproject_last_check" ]; then
    LAST_CHECK=$(cat "/data/adb/xproject_last_check")
fi

CURRENT_TIME=$(date +%s)
HOURS_SINCE_LAST_CHECK=$(( (CURRENT_TIME - LAST_CHECK) / 3600 ))

if [ "$HOURS_SINCE_LAST_CHECK" -ge 24 ]; then
    # Run update check in background
    nohup sh $MODDIR/common/xproject_update.sh check > /dev/null 2>&1 &
    echo "$CURRENT_TIME" > "/data/adb/xproject_last_check"
fi

rm -f "$UPDATE_LOCK"