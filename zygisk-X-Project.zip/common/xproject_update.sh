#!/system/bin/sh

# Telegram channel for notifications
TELEGRAM_CHANNEL="https://t.me/XProjectAB"

MODDIR="/data/adb/modules/template_p"
UPDATE_URL="https://raw.githubusercontent.com/Xgoushi/mystuff/refs/heads/main/update.json"
VERSION_INFO="$MODDIR/version.info"
LOG_FILE="/data/adb/xproject_update.log"

# Logging function
log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" >> $LOG_FILE
}

# Get current version
CURRENT_VERSION=$(grep 'version=' $MODDIR/module.prop | cut -d= -f2)
CURRENT_CODE=$(grep 'versionCode=' $MODDIR/module.prop | cut -d= -f2)

# Notification function
notify() {
    # You can implement notification via:
    # 1. Telegram bot API
    # 2. Android notification
    # 3. Toast message
    log "$1"
}

check_update() {
    log "Checking for updates..."
    response=$(curl -s "$UPDATE_URL?module=xproject&version=$CURRENT_VERSION&code=$CURRENT_CODE")
    
    if [ -z "$response" ]; then
        log "Failed to check for updates"
        return 1
    fi

    new_version=$(echo "$response" | jq -r '.version')
    new_code=$(echo "$response" | jq -r '.versionCode')
    download_url=$(echo "$response" | jq -r '.downloadUrl')
    changelog=$(echo "$response" | jq -r '.changelog')
    mandatory=$(echo "$response" | jq -r '.mandatory')
    
    if [ "$new_code" -gt "$CURRENT_CODE" ]; then
        log "Update available: $new_version (Current: $CURRENT_VERSION)"
        log "Changelog: $changelog"
        notify "New X-Project-AB v$new_version available! Visit $TELEGRAM_CHANNEL"
        
        # If update is mandatory, download automatically
        if [ "$mandatory" = "true" ]; then
            log "Mandatory update detected, proceeding with installation"
            download_update
        fi
        return 0
    else
        log "No updates available"
        return 1
    fi
}

download_update() {
    log "Starting download..."
    tmp_file="/data/local/tmp/xproject_update_$new_version.zip"
    
    if curl -L "$download_url" -o "$tmp_file"; then
        log "Download complete. Verifying..."
        
        # Basic verification (you should add signature verification)
        if [ $(stat -c%s "$tmp_file") -lt 10000 ]; then
            log "Downloaded file too small, possibly corrupted"
            rm -f "$tmp_file"
            return 1
        fi
        
        log "Installing update..."
        magisk --install-module "$tmp_file" && {
            log "Update installed successfully"
            rm -f "$tmp_file"
            notify "X-Project-AB updated to v$new_version successfully!"
            return 0
        } || {
            log "Installation failed"
            notify "Update installation failed! Please check $TELEGRAM_CHANNEL"
            return 1
        }
    else
        log "Download failed"
        notify "Failed to download update. Check your connection."
        return 1
    fi
}

# Main execution
case "$1" in
    "check")
        check_update
        ;;
    "update")
        check_update && download_update
        ;;
    "force-update")
        download_url="$2"
        new_version="$3"
        download_update
        ;;
    *)
        echo "Usage: $0 [check|update|force-update URL VERSION]"
        ;;
esac